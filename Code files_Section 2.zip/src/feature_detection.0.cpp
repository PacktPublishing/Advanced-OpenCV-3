#include "opencv2/opencv.hpp"
using namespace cv;
int main(int argc, const char* argv[])
{
    for (int i=1;i<argc; i+=2)                          // read image pairs
    {
        Mat img1 = imread(argv[i]);                     // read img1
        Mat img2 = imread(argv[i+1]);                   // read img2

        Ptr<Feature2D> detector = AKAZE::create();      // create detector
        std::vector<KeyPoint> keypoints1, keypoints2;
        detector->detect(img1, keypoints1);             // detect img1 feature keypoints
        detector->detect(img2, keypoints2);             // detect img2 feature keypoints

        Mat img_keypoints1, img_keypoints2;             // generate keypoint display images
        drawKeypoints(img1, keypoints1, img_keypoints1);
        imshow("Keypoints of 'img1'", img_keypoints1), waitKey(0);
        drawKeypoints(img2, keypoints2, img_keypoints2, Scalar::all(-1), DrawMatchesFlags::DRAW_RICH_KEYPOINTS );
        imshow("Keypoints of 'img2' + scale and angle", img_keypoints2), waitKey(0);
        destroyAllWindows();                            // close window
    }
}