#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
int main(int argc, char **argv)
{   // read and initialize network with files from https://github.com/weiliu89/caffe/tree/ssd#models
    auto net = cv::dnn::readNetFromCaffe("deploy.prototxt", "VGG_VOC0712_SSD_300x300_iter_120000.caffemodel");   
    if (net.empty()) return std::cerr << "DNN loading failed.\n", EXIT_FAILURE;                 
    std::vector<std::string> classNames = { "Background", "Aeroplane", "Bicycle", "Bird", "Boat", "Bottle", "Bus", "Car", "Cat", "Chair", "Cow", "Dining table", "Dog", "Horse", "Motorbike", "Person", "Potted plant", "Sheep", "Sofa", "Train", "TV/Monitor" };
    std::vector<cv::Scalar> colors = { { 0,0,0 },{ 128,0,0 },{ 0,128,0 },{ 128,128,0 },{ 0,0,128 },{ 128,0,128 },{ 0,128,128 },{ 128,128,128 },{ 64,0,0 },{ 192,0,0 },{ 64,128,0 },{ 192,128,0 },{ 64,0,128 },{ 192,0,128 },{ 64,128,128 },{ 192,128,128 },{ 0,64,0 },{ 128,64,0 },{ 0,192,0 },{ 128,192,0 },{ 0,64,128 } };
    for (auto imgFile : std::vector<char*>(argv + 1, argv + argc))
    {
        cv::Mat resized, img = cv::imread(imgFile);                                     // read image
        if (img.empty()) continue;
        cv::resize(img, resized, { 300,300 });                                          // convert to SSD 300x300 RGB-image  
        net.setInput(cv::dnn::blobFromImage(resized,1,{},{104,117,123}),"data");        // feed the network input
        cv::Mat detection = net.forward("detection_out");                               // runs network forward pass 
        cv::Mat boxes(detection.size[2], detection.size[3], CV_32F, detection.ptr<float>());
        for (int i = 0; i < boxes.rows; i++)
        {
            auto confidence = boxes.at<float>(i, 2);                                    // get detection confidence 
            if (confidence < 0.5) continue;                                             // skip if too low
            cv::Point TL(boxes.at<float>(i,3)*img.cols, boxes.at<float>(i,4)*img.rows); // get top-left corner
            cv::Point BR(boxes.at<float>(i,5)*img.cols, boxes.at<float>(i,6)*img.rows); // get bottom-right corner
            size_t objectClass = (size_t)(boxes.at<float>(i, 1));                       // get object class index
            cv::rectangle(img, { TL, BR }, colors[objectClass], 2);                     // draw rectangle with class color
            putText(img, classNames[objectClass], TL + cv::Point{4,15}, cv::FONT_HERSHEY_PLAIN, 1, {}, 2, CV_AA); // label object 
            putText(img, classNames[objectClass], TL + cv::Point{4,15}, cv::FONT_HERSHEY_PLAIN, 1, {255,255,255}, 1, CV_AA); 
        }
        imshow("detections", img); cv::waitKey();
    }
}