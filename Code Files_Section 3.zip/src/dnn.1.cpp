#include <iterator>
#include <iosfwd>
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
using namespace std; using namespace cv;
class Line: public string { friend istream& operator>>(istream& is, Line& line){ return getline(is, line); } };
int main(int argc, char **argv)
{   // read and initialize network with files from https://storage.googleapis.com/download.tensorflow.org/models/inception5h.zip
    auto net = dnn::readNetFromTensorflow("tensorflow_inception_graph.pb");   
    if (net.empty()) return std::cerr << "DNN loading failed.\n", EXIT_FAILURE;                 
    vector<string> classNames;                                                
    transform(istream_iterator<Line>(ifstream("imagenet_comp_graph_label_strings.txt")), istream_iterator<Line>(),   
              back_insert_iterator<vector<string>>(classNames), [](auto&& line){ return line; }); // read class names from file

    for (auto imgFile : vector<char*>(argv + 1, argv + argc))
    {
        Mat img = imread(imgFile);                                                    // read image
        if (img.empty()) continue;
        Mat inputBlob = dnn::blobFromImage(img, 1, {224, 224}, {104, 117, 123});      // convert to GoogLeNet 224x224 RGB-image
        net.setInput(inputBlob, "input");                                             // feed the network input
        Mat prob = net.forward("softmax2");                                           // runs network forward pass 
        auto maxElem = max_element(prob.ptr<float>(), prob.ptr<float>() + prob.cols); // find class with maximal probability
        auto result = "(" + to_string(int(*maxElem * 100)) + "%): " + classNames[maxElem - prob.ptr<float>()];
        cout << "Predicted " << result << '\n';
        imshow("Input image", img); setWindowTitle("Input image", result); waitKey(); 
    }
}