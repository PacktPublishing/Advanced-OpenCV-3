#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
using namespace std; using namespace cv;

void colorizeSegmentation(const cv::Mat &score, const vector<cv::Vec3b> &colors, cv::Mat &segm);

int main(int argc, char **argv)
{   // read and initialize network with files from http://dl.caffe.berkeleyvision.org/ 
    auto net = dnn::readNetFromCaffe("fcn8s-heavy-pascal.prototxt", "fcn8s-heavy-pascal.caffemodel");   
    if (net.empty()) return std::cerr << "DNN loading failed.\n", EXIT_FAILURE;
    vector<Vec3b> colors = {{0,0,0},{128,0,0},{0,128,0},{128,128,0},{0,0,128},{128,0,128},{0,128,128},{128,128,128},{64,0,0},{192,0,0},{64,128,0},{192,128,0},{64,0,128},{192,0,128},{64,128,128},{192,128,128},{0,64,0},{128,64,0},{0,192,0},{128,192,0},{0,64,128}};
    for (auto imgFile : vector<char*>(argv + 1, argv + argc))
    {
        Mat img = imread(imgFile);                          // read image
        if (img.empty()) continue;
        imshow("Input image", img); waitKey(1);
        auto orgSize = img.size();
        resize(img, img, { 500, 500 });                     // convert to FCN 500x500 RGB-image
        Mat inputBlob = dnn::blobFromImage(img);            
        net.setInput(inputBlob, "data");                    // feed the network input
        Mat score = net.forward("score");                   // runs network forward pass 
        Mat colorized;                                      // for output pixel vector choose max as class
        colorizeSegmentation(score, colors, colorized);     // create color segmentation
        resize(img * 0.4 + colorized * 0.6, img, orgSize);  // resize segmentation and overlay on img
        imshow("Segmentation", img); waitKey(0);        
    }
}