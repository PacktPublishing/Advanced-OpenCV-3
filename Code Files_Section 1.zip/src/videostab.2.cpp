#include "opencv2/opencv.hpp"
using namespace cv::videostab;
using namespace cv;
int main(int argc, const char* argv[])
{
   auto stabilizer = makePtr<OnePassStabilizer>();                  // create stabilizer
   stabilizer->setFrameSource(makePtr<VideoFileSource>(argv[1]));   // set input source
   stabilizer->setLog(makePtr<NullLog>());                          // disable console output logging

   int frame_radius = 30;                                           // choose larger stabilization frame radius
   stabilizer->setMotionFilter(makePtr<GaussianMotionFilter>(frame_radius));
   stabilizer->setRadius(frame_radius);

   auto inpainters = makePtr<InpaintingPipeline>();                 // set up border inpainting pipeline
   inpainters->pushBack(makePtr<ConsistentMosaicInpainter>());      // with mosaicing inpainter
   inpainters->setRadius(frame_radius);
   stabilizer->setInpainter(inpainters);  

   Mat stabilizedFrame, both;
   auto vid_to_disp = makePtr<VideoFileSource>(argv[1]);                           // open again for display
   while (!(stabilizedFrame = stabilizer->nextFrame()).empty() && 27 != waitKey(1))// loop to end or ESC
   {
      hconcat(vid_to_disp->nextFrame(), stabilizedFrame, both);  // concat
      imshow("Original ::: Stabilized", both);                             // and show
   } 
} 