#include "opencv2/bgsegm.hpp"
#include "opencv2/opencv.hpp"
using namespace cv;
int main(int argc, const char* argv[])
{
    VideoCapture cap(argv[1]);                                                  // Open video file
    auto bgSub = cv::bgsegm::createBackgroundSubtractorCNT();                   // Create Background Subtractor
    Mat vid_frame, frame, fgmask, disp, bgimg;
    std::vector<std::vector<cv::Point>> contours;
    while (27 != waitKey(1))                                                    // Play until ESC
    {        
        cap >> vid_frame;                                                       // Capture frame
        if (vid_frame.empty()) { cap.open(argv[1]); continue; }                 // On end, reopen video        
        resize(vid_frame, frame, {800, 800 * vid_frame.rows / vid_frame.cols}); // Resize input frame and show it 
        imshow("Input Video Frame", frame);                                     //   and show it
        bgSub->apply(frame, fgmask);                                            // Update BG model
        imshow("Foreground Mask", fgmask);                                      //   and show FG mask
        bgSub->getBackgroundImage(bgimg);                                       // Get background image 
        if (!bgimg.empty()) imshow("Reconstructed Background Image", bgimg);    //   and show it (if/when available)

        // Create a pretty segmentation display
        morphologyEx(fgmask, fgmask, MORPH_OPEN,{});                            // Clean up mask
        disp = frame * 0.5;                                                     // Create darker frame 
        add(frame, Scalar(0, 100, 0), disp, fgmask);                            // Overlay clean mask in green
        findContours(fgmask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);     // Perform connected-components on clean mask
        for (auto&& contour : contours)
            cv::rectangle(disp, boundingRect(contour), Scalar(0,255,255));      // Draw bounding rectangle around each blob
        imshow("Foreground Segmentation", disp);                                //   and show the result
    }
}