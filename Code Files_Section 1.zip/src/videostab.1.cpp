#include "opencv2/opencv.hpp"
using namespace cv::videostab;
using namespace cv;
int main(int argc, const char* argv[])
{
   auto vid_to_stab = makePtr<VideoFileSource>(argv[1]);   // create video source to stabilize
   auto vid_to_disp = makePtr<VideoFileSource>(argv[1]);   // open again for display

   auto stabilizer = makePtr<OnePassStabilizer>();         // create one-pass "online" Stabilizer
   stabilizer->setFrameSource(vid_to_stab);                // set the frame source to the input video
   // stabilizer->setBorderMode(BORDER_CONSTANT);             // show black borders

   Mat stabilizedFrame, both;
   while (!(stabilizedFrame = stabilizer->nextFrame()).empty() && 27 != waitKey(1)) // loop to end or ESC
   {
      hconcat(vid_to_disp->nextFrame(), stabilizedFrame, both);  // hconcat the original and stabilized frames
      imshow("Original ::: Stabilized", both);                   // and show them
   } 
} 